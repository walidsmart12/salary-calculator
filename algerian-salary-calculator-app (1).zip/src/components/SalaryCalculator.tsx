import { useState, useMemo } from 'react';
import {
  GraduationCap,
  Briefcase,
  Wrench,
  FlaskConical,
  ChevronDown,
  Users,
  Baby,
  MapPin,
  Star,
  Clock,
  Calculator,
  RotateCcw,
  Heart,
  Percent,
  CalendarMinus,
  Crown,
  TrendingUp,
} from 'lucide-react';
import {
  EmployeeCategory,
  getGradesByCategory,
  ZONES,
  calculateFullSalary,
  Grade,
  SPECIFIC_POSITIONS,
} from '../data/salaryData';
import SalaryResult from './SalaryResult';

const CATEGORIES: { id: EmployeeCategory; name: string; icon: React.ReactNode; color: string; gradient: string }[] = [
  {
    id: 'professor',
    name: 'الأساتذة',
    icon: <GraduationCap className="w-6 h-6" />,
    color: 'blue',
    gradient: 'from-blue-500 to-blue-600',
  },
  {
    id: 'researcher',
    name: 'الباحثون',
    icon: <FlaskConical className="w-6 h-6" />,
    color: 'purple',
    gradient: 'from-purple-500 to-purple-600',
  },
  {
    id: 'admin',
    name: 'الإداريون',
    icon: <Briefcase className="w-6 h-6" />,
    color: 'emerald',
    gradient: 'from-emerald-500 to-emerald-600',
  },
  {
    id: 'technician',
    name: 'التقنيون والمهندسون',
    icon: <Wrench className="w-6 h-6" />,
    color: 'amber',
    gradient: 'from-amber-500 to-amber-600',
  },
];

function SelectField({
  label,
  value,
  onChange,
  options,
  icon,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  icon: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <label className="flex items-center gap-1.5 text-sm font-medium golden-title">
         {icon}
         {label}
       </label>
       <div className="relative">
         <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="golden-field golden-border-hover w-full bg-white/5 rounded-xl px-4 py-3 text-sm font-semibold appearance-none cursor-pointer focus:outline-none transition-all duration-300 hover:bg-white/8"
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-yellow-500 pointer-events-none" />
      </div>
    </div>
  );
}

function NumberField({
  label,
  value,
  onChange,
  min,
  max,
  icon,
  suffix,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  icon: React.ReactNode;
  suffix?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label className="flex items-center gap-1.5 text-sm font-medium golden-title">
         {icon}
         {label}
       </label>
       <div className="relative">
         <input
          type="number"
          value={value}
          onChange={(e) => {
            const v = parseInt(e.target.value) || 0;
            onChange(Math.max(min, Math.min(max, v)));
          }}
          min={min}
          max={max}
          className="golden-field golden-border-hover w-full bg-white/5 rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none transition-all duration-300 hover:bg-white/8"
        />
        {suffix && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold" style={{ color: '#daa520' }}>
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
}

function CheckboxField({
  label,
  checked,
  onChange,
  icon,
  description,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  icon: React.ReactNode;
  description?: string;
}) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div
        className={`w-5 h-5 mt-0.5 rounded-md border-2 flex items-center justify-center transition-all duration-300 flex-shrink-0 ${
          checked
            ? 'border-yellow-500 shadow-lg shadow-yellow-500/30'
            : 'border-gray-500 group-hover:border-yellow-600'
        }`}
        style={checked ? { background: 'linear-gradient(135deg, #ffd700, #daa520)' } : {}}
        onClick={() => onChange(!checked)}
      >
        {checked && (
          <svg className="w-3 h-3 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        )}
      </div>
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 text-sm golden-title font-medium">
           {icon}
           {label}
         </div>
         {description && (
           <span className="text-xs silver-title mt-0.5">{description}</span>
        )}
      </div>
    </label>
  );
}

export default function SalaryCalculator() {
  const [employeeCategory, setEmployeeCategory] = useState<EmployeeCategory>('professor');
  const [gradeId, setGradeId] = useState<string>('');
  const [step, setStep] = useState<number>(1);
  const [experienceYears, setExperienceYears] = useState<number>(0);
  const [zone, setZone] = useState<string>('zone1');
  // المردودية اختيارية (ربع سنوية)
  const [hasPerformance, setHasPerformance] = useState<boolean>(false);
  const [performanceRate, setPerformanceRate] = useState<number>(40);
  const [absenceDays, setAbsenceDays] = useState<number>(0);
  const [isMarried, setIsMarried] = useState<boolean>(false);
  const [childrenCount, setChildrenCount] = useState<number>(0);
  const [hasSpecificPosition, setHasSpecificPosition] = useState<boolean>(false);
  const [specificPositionId, setSpecificPositionId] = useState<string>('none');
  const [showResult, setShowResult] = useState<boolean>(false);

  const grades = useMemo(() => getGradesByCategory(employeeCategory), [employeeCategory]);

  const selectedGrade = useMemo(
    () => grades.find((g) => g.id === gradeId) || grades[0],
    [grades, gradeId]
  );

  const currentGrade: Grade = selectedGrade || grades[0];

  const currentZone = useMemo(() => ZONES.find((z) => z.id === zone), [zone]);
  const zoneRate = currentZone?.rate || 0;
  const zoneName = currentZone?.name || '';

  // فلترة المناصب النوعية حسب الفئة
  const availablePositions = useMemo(
    () => SPECIFIC_POSITIONS.filter((p) => p.forCategory.includes(employeeCategory)),
    [employeeCategory]
  );

  const selectedPosition = useMemo(
    () => SPECIFIC_POSITIONS.find((p) => p.id === specificPositionId),
    [specificPositionId]
  );

  const result = useMemo(() => {
    if (!currentGrade) return null;
    const posRate = hasSpecificPosition && selectedPosition ? selectedPosition.rate : 0;
    const posName = hasSpecificPosition && selectedPosition && selectedPosition.id !== 'none'
      ? selectedPosition.name : '';
    return calculateFullSalary(
      currentGrade,
      step,
      experienceYears,
      zoneRate,
      hasPerformance,
      performanceRate,
      absenceDays,
      isMarried,
      childrenCount,
      posRate,
      posName,
    );
  }, [currentGrade, step, experienceYears, zoneRate, hasPerformance, performanceRate, absenceDays,
      isMarried, childrenCount, hasSpecificPosition, selectedPosition]);

  const handleCategoryChange = (cat: EmployeeCategory) => {
    setEmployeeCategory(cat);
    setGradeId('');
    setHasSpecificPosition(false);
    setSpecificPositionId('none');
    setShowResult(false);
  };

  const handleReset = () => {
    setStep(1);
    setExperienceYears(0);
    setZone('zone1');
    setHasPerformance(false);
    setPerformanceRate(40);
    setAbsenceDays(0);
    setIsMarried(false);
    setChildrenCount(0);
    setHasSpecificPosition(false);
    setSpecificPositionId('none');
    setShowResult(false);
  };

  const handleCalculate = () => {
    setShowResult(true);
  };

  return (
    <div className="space-y-6">
      {/* Category Selection */}
      <div className="glass-card-dark rounded-2xl p-5 animate-slide-in-up">
        <h3 className="text-sm font-bold golden-title mb-4 flex items-center gap-2">
          <Users className="w-4 h-4 text-yellow-400" />
          اختر فئة الموظف
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryChange(cat.id)}
              className={`relative overflow-hidden rounded-xl p-4 flex flex-col items-center gap-2 transition-all duration-500 group ${
                employeeCategory === cat.id
                  ? `bg-gradient-to-br ${cat.gradient} shadow-lg scale-[1.02]`
                  : 'bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20'
              }`}
            >
              {employeeCategory === cat.id && (
                <div className="absolute inset-0 bg-white/10 animate-shimmer" style={{ backgroundSize: '200% 100%' }} />
              )}
              <span
                className={`relative z-10 transition-transform duration-300 group-hover:scale-110 ${
                  employeeCategory === cat.id ? 'text-white' : 'text-yellow-600'
                }`}
              >
                {cat.icon}
              </span>
               <span
                 className={`relative z-10 text-xs font-bold ${
                   employeeCategory === cat.id ? 'text-white' : 'golden-title'
                 }`}
                >
                {cat.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Form Fields */}
      <div className="glass-card-dark rounded-2xl p-5 animate-slide-in-up">
        <h3 className="text-sm font-bold golden-title mb-4 flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-yellow-400" />
          المعلومات الوظيفية
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="الرتبة"
            value={gradeId || (grades[0]?.id ?? '')}
            onChange={(v) => { setGradeId(v); setShowResult(false); }}
            options={grades.map((g) => ({ value: g.id, label: `${g.name} (صنف ${g.category})` }))}
            icon={<GraduationCap className="w-3.5 h-3.5 text-blue-400" />}
          />

          <NumberField
            label="الدرجة"
            value={step}
            onChange={(v) => { setStep(v); setShowResult(false); }}
            min={0}
            max={12}
            icon={<Star className="w-3.5 h-3.5 text-yellow-400" />}
          />

          <NumberField
            label="سنوات الخبرة (الأقدمية)"
            value={experienceYears}
            onChange={(v) => { setExperienceYears(v); setShowResult(false); }}
            min={0}
            max={40}
            icon={<Clock className="w-3.5 h-3.5 text-purple-400" />}
            suffix="سنة"
          />

          <SelectField
            label="المنطقة الجغرافية"
            value={zone}
            onChange={(v) => { setZone(v); setShowResult(false); }}
            options={ZONES.map((z) => ({ value: z.id, label: z.name }))}
            icon={<MapPin className="w-3.5 h-3.5 text-red-400" />}
          />

          <NumberField
            label="عدد الأطفال"
            value={childrenCount}
            onChange={(v) => { setChildrenCount(v); setShowResult(false); }}
            min={0}
            max={10}
            icon={<Baby className="w-3.5 h-3.5 text-pink-400" />}
          />
        </div>

        <div className="mt-4 pt-4 border-t border-white/5">
          <CheckboxField
            label="متزوج(ة)"
            checked={isMarried}
            onChange={(v) => { setIsMarried(v); setShowResult(false); }}
            icon={<Heart className="w-3.5 h-3.5 text-red-400" />}
          />
        </div>
      </div>

      {/* Performance Section - Optional Quarterly */}
      <div className="glass-card-dark rounded-2xl p-5 animate-slide-in-up">
        <h3 className="text-sm font-bold golden-title mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-yellow-400" />
          منحة المردودية الفردية (PRI)
           <span className="text-[10px] bg-white/10 silver-title px-2 py-0.5 rounded-full font-bold mr-1">ربع سنوية</span>
        </h3>
        <div className="space-y-4">
          <CheckboxField
            label="شهر مردودية (الشهر يتضمن منحة مردودية)"
            checked={hasPerformance}
            onChange={(v) => {
              setHasPerformance(v);
              if (!v) {
                setAbsenceDays(0);
              }
              setShowResult(false);
            }}
            icon={<Percent className="w-3.5 h-3.5 text-amber-400" />}
            description="المردودية تُصرف كل 3 أشهر (ربع سنوية) — فعّل هذا الخيار إذا كان الشهر المحسوب يتضمن منحة مردودية"
          />

          {hasPerformance && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-xl bg-amber-500/5 border border-amber-500/15">
              <NumberField
                label="نسبة المردودية (PRI)"
                value={performanceRate}
                onChange={(v) => { setPerformanceRate(v); setShowResult(false); }}
                min={0}
                max={40}
                icon={<Percent className="w-3.5 h-3.5 text-amber-400" />}
                suffix="%"
              />

              <NumberField
                label="عدد أيام الغياب في الثلاثي"
                value={absenceDays}
                onChange={(v) => { setAbsenceDays(v); setShowResult(false); }}
                min={0}
                max={66}
                icon={<CalendarMinus className="w-3.5 h-3.5 text-orange-400" />}
                suffix="يوم"
              />
            </div>
          )}

          {hasPerformance && absenceDays > 0 && (
            <div className="p-3 rounded-xl bg-orange-500/10 border border-orange-500/20">
              <p className="text-xs text-orange-300">
                ⚠️ سيتم خصم <span className="font-bold">{absenceDays} يوم</span> من منحة المردودية.
                أيام العمل الفعلية في الثلاثي: <span className="font-bold">{Math.max(0, 66 - absenceDays)} / 66 يوم</span>
              </p>
            </div>
          )}

          {!hasPerformance && (
            <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <p className="text-xs text-blue-300">
                ℹ️ الراتب سيُحسب <span className="font-bold">بدون منحة المردودية</span>. المردودية تُصرف فقط كل ثلاثة أشهر (مارس، جوان، سبتمبر، ديسمبر).
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Specific Position Section */}
      <div className="glass-card-dark rounded-2xl p-5 animate-slide-in-up">
        <h3 className="text-sm font-bold golden-title mb-4 flex items-center gap-2">
          <Crown className="w-4 h-4 text-yellow-400" />
          المنصب النوعي
        </h3>
        <div className="space-y-4">
          <CheckboxField
            label="مستفيد من منصب نوعي"
            checked={hasSpecificPosition}
            onChange={(v) => {
              setHasSpecificPosition(v);
              if (!v) setSpecificPositionId('none');
              setShowResult(false);
            }}
            icon={<Crown className="w-3.5 h-3.5 text-yellow-400" />}
            description="تعويض إضافي للمسؤوليات الإدارية (رئيس قسم، عميد، مدير...)"
          />

          {hasSpecificPosition && (
            <div className="p-4 rounded-xl bg-yellow-500/5 border border-yellow-500/15">
              <SelectField
                label="اختر المنصب النوعي"
                value={specificPositionId}
                onChange={(v) => { setSpecificPositionId(v); setShowResult(false); }}
                options={availablePositions.map((p) => ({
                  value: p.id,
                  label: `${p.name}${p.rate > 0 ? ` (${p.rate}%)` : ''}`,
                }))}
                icon={<Crown className="w-3.5 h-3.5 text-yellow-400" />}
              />
            </div>
          )}

          {hasSpecificPosition && selectedPosition && selectedPosition.rate > 0 && (
            <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
              <p className="text-xs text-yellow-300">
                ✨ منصب نوعي: <span className="font-bold">{selectedPosition.name}</span> —
                تعويض إضافي بنسبة <span className="font-bold">{selectedPosition.rate}%</span> من الراتب الأساسي
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <button
          onClick={handleCalculate}
          className="flex-1 relative overflow-hidden group bg-gradient-to-l from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white font-bold py-4 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 flex items-center justify-center gap-3"
        >
          <div className="absolute inset-0 bg-white/10 translate-x-full group-hover:translate-x-0 transition-transform duration-500" />
          <Calculator className="w-5 h-5 relative z-10" />
          <span className="relative z-10 text-lg">حساب الراتب</span>
        </button>
        <button
          onClick={handleReset}
          className="px-6 py-4 rounded-xl bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 hover:text-white transition-all duration-300 flex items-center gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          <span className="hidden md:inline">إعادة</span>
        </button>
      </div>

      {/* Result */}
      {showResult && result && (
        <SalaryResult
          result={result}
          gradeName={currentGrade.name}
          gradeCategory={currentGrade.category}
          step={step}
          experienceYears={experienceYears}
          categoryType={employeeCategory}
          zoneName={zoneName}
          isMarried={isMarried}
          childrenCount={childrenCount}
        />
      )}
    </div>
  );
}
