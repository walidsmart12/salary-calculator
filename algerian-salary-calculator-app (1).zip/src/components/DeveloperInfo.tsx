import { Phone, MapPin, User, Code, Heart, Globe, Briefcase, Building2, Award, Star } from 'lucide-react';

export default function DeveloperInfo() {
  return (
    <div className="mt-10 animate-slide-in-up">
      <div className="glass-card-dark rounded-3xl p-6 md:p-10 relative overflow-hidden border border-yellow-500/10">
        {/* Decorative corner elements */}
        <div className="absolute top-0 left-0 w-40 h-40 bg-gradient-to-br from-yellow-500/10 to-transparent rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-gradient-to-tl from-emerald-500/10 to-transparent rounded-full translate-x-1/2 translate-y-1/2" />

        {/* Gold line at top */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-yellow-400/60 to-transparent" />

        <div className="relative z-10">
          {/* Section Title */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <Star className="w-4 h-4 text-yellow-400 animate-pulse" />
            <Code className="w-5 h-5 text-yellow-400" />
            <h3 className="text-xl font-black golden-title-lg tracking-wide">
              المطوّر والمصمّم
            </h3>
            <Code className="w-5 h-5 text-yellow-400" />
            <Star className="w-4 h-4 text-yellow-400 animate-pulse" />
          </div>

          {/* Developer Info Card */}
          <div className="flex flex-col sm:flex-row items-center gap-6 max-w-xl mx-auto">
            {/* Developer Photo - 3D Golden Circle */}
            <div className="relative flex-shrink-0 group dev-photo-3d">
              {/* Background glow */}
              <div className="dev-photo-3d-glow" />
              {/* Outer golden ring */}
              <div className="dev-photo-3d-outer" />
              {/* Middle bevel ring */}
              <div className="dev-photo-3d-mid" />
              {/* Inner golden ring */}
              <div className="dev-photo-3d-inner" />
              {/* Photo */}
              <div className="dev-photo-3d-img">
                <img
                  src="https://i.imgur.com/Fa2bMsr.jpeg"
                  alt="دغبوج وليد"
                />
              </div>
              {/* 3D Shine overlay */}
              <div className="dev-photo-3d-shine" />
              {/* Verified badge */}
              <div className="absolute bottom-2 right-2 w-9 h-9 rounded-full flex items-center justify-center z-10"
                   style={{
                     background: 'linear-gradient(145deg, #ffd700, #daa520)',
                     boxShadow: '0 3px 8px rgba(0,0,0,0.5), 0 0 10px rgba(255,215,0,0.5), inset 0 1px 2px rgba(255,255,255,0.5), inset 0 -1px 2px rgba(0,0,0,0.3)',
                     border: '2px solid #0f172a'
                   }}>
                <span className="text-black text-sm font-black">✓</span>
              </div>
            </div>

            {/* Developer Details */}
            <div className="flex-1 text-center sm:text-right space-y-3">
              {/* Name */}
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <User className="w-5 h-5 text-yellow-400" />
                <h4 className="text-xl font-black golden-title-lg">
                  دغبوج وليد
                </h4>
              </div>

              {/* Job Title */}
              <div className="flex items-center justify-center sm:justify-start gap-2">
               <Briefcase className="w-4 h-4 text-emerald-400" />
                 <span className="text-sm font-bold silver-title-lg">متصرف مستشار</span>
                 <Award className="w-4 h-4 text-yellow-400" />
               </div>

               {/* Workplace */}
               <div className="flex items-center justify-center sm:justify-start gap-2">
                 <Building2 className="w-4 h-4 text-blue-400" />
                 <span className="text-sm font-semibold silver-title-lg">جامعة العربي التبسي - تبسة</span>
               </div>

              {/* Divider */}
              <div className="w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent my-2" />

              {/* Location & Contact */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-sm">
              <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5">
                   <Globe className="w-4 h-4 text-emerald-400" />
                   <span className="silver-title font-medium text-sm">الجزائر</span>
                 </div>
                 <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5">
                   <MapPin className="w-4 h-4 text-red-400" />
                   <span className="silver-title font-medium text-sm">تبسة</span>
                 </div>
                 <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5" dir="ltr">
                   <Phone className="w-4 h-4 text-green-400" />
                   <span className="text-xs silver-title font-medium">00213770374898</span>
                 </div>
              </div>

              {/* Made with love */}
              <div className="flex items-center justify-center sm:justify-start gap-2 text-xs pt-1">
                 <span className="silver-title font-medium">صُنع بـ</span>
                 <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 animate-pulse" />
                 <span className="silver-title font-medium">في الجزائر 🇩🇿</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
