import {
  Banknote,
  TrendingUp,
  TrendingDown,
  Calculator,
  Shield,
  FileText,
  Printer,
  BookOpen,
  Award,
  Heart,
  Baby,
  MapPin,
  Crown,
  CalendarDays,
  CalendarRange,
} from 'lucide-react';
import { SalaryResult as SalaryResultType, formatCurrency, EmployeeCategory, getCategoryLabel, SNMG, POINT_VALUE } from '../data/salaryData';

interface Props {
  result: SalaryResultType;
  gradeName: string;
  gradeCategory: number;
  step: number;
  experienceYears: number;
  categoryType: EmployeeCategory;
  zoneName: string;
  isMarried: boolean;
  childrenCount: number;
}

function SalaryRow({
  label,
  value,
  type = 'normal',
  icon,
  rate,
}: {
  label: string;
  value: number;
  type?: 'normal' | 'positive' | 'negative' | 'total' | 'grand';
  icon?: React.ReactNode;
  rate?: string;
}) {
  const colorClass =
    type === 'positive'
      ? 'text-emerald-400'
      : type === 'negative'
      ? 'text-red-400'
      : type === 'total'
      ? 'text-yellow-400 font-bold text-lg'
      : type === 'grand'
      ? 'text-emerald-300 font-black text-xl'
      : 'text-gray-200';

  const bgClass = type === 'total'
    ? 'bg-gradient-to-l from-yellow-500/10 to-transparent'
    : type === 'grand'
    ? 'bg-gradient-to-l from-emerald-500/10 to-transparent'
    : '';

  return (
    <div className={`flex items-center justify-between py-2.5 px-3 rounded-lg transition-all duration-300 hover:bg-white/5 ${bgClass}`}>
      <div className="flex items-center gap-2">
         {icon && <span className="text-gray-400">{icon}</span>}
         <span className={`text-sm ${type === 'total' || type === 'grand' ? 'font-bold text-base golden-title' : 'silver-title font-medium'}`}>
           {label}
           {rate && <span className="text-xs text-gray-500 mr-1">({rate})</span>}
         </span>
       </div>
      <span className={`font-semibold tabular-nums ${colorClass}`} dir="ltr">
        {type === 'negative' ? '- ' : ''}{formatCurrency(Math.abs(value))}
      </span>
    </div>
  );
}

function generatePrintHTML(
  result: SalaryResultType,
  gradeName: string,
  gradeCategory: number,
  step: number,
  experienceYears: number,
  categoryType: EmployeeCategory,
  zoneName: string,
  isMarried: boolean,
  childrenCount: number,
  isAnnual: boolean,
): string {
  const currentDate = new Date();
  const monthNames = [
    'جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان',
    'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  const multiplier = isAnnual ? 12 : 1;
  const periodLabel = isAnnual ? 'السنوي' : 'الشهري';
  const periodTitle = isAnnual
    ? `كشف تقديري للراتب السنوي — ${currentDate.getFullYear()}`
    : `كشف تقديري للراتب الشهري — ${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`;

  const fmt = (n: number) => {
    const val = n * multiplier;
    return new Intl.NumberFormat('ar-DZ', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val) + ' د.ج';
  };

  // Build allowance rows
  const rows: string[] = [];
  let rowNum = 1;
  const addRow = (label: string, rate: string, amount: string, cls = '') => {
    rows.push(`<tr class="${cls}"><td class="num">${rowNum++}</td><td>${label}</td><td class="rate">${rate}</td><td class="amount">${amount}</td></tr>`);
  };

  addRow('الراتب الأساسي', `الرقم الاستدلالي ${result.indexNumber} × ${POINT_VALUE} د.ج`, fmt(result.baseSalary));
  addRow('تعويض الخبرة المهنية', `${result.experienceRate}%`, fmt(result.experienceAllowance));

  if (result.pedagogicalAllowance > 0) {
    addRow('التعويض البيداغوجي', '%', fmt(result.pedagogicalAllowance));
  }
  if (result.qualificationAllowance > 0) {
    addRow('تعويض التأهيل', '%', fmt(result.qualificationAllowance));
  }
  if (result.documentationAllowance > 0) {
    addRow('منحة التوثيق', 'مبلغ ثابت', fmt(result.documentationAllowance));
  }
  addRow('المنحة الخاصة بالمنصب', '%', fmt(result.specificAllowance));
  if (result.supervisionAllowance > 0) {
    addRow('منحة التأطير', '%', fmt(result.supervisionAllowance));
  }
  if (result.riskAllowance > 0) {
    addRow('تعويض الضرر', '%', fmt(result.riskAllowance));
  }
  if (result.zoneAllowance > 0) {
    addRow('تعويض المنطقة الجغرافية', '%', fmt(result.zoneAllowance));
  }

  if (result.hasPerformance) {
    const perfNote = result.absenceDays > 0
      ? `${result.performanceRate}% — ${result.effectiveWorkDays}/22 يوم عمل`
      : `${result.performanceRate}%`;
    addRow('منحة المردودية (PRI) — ربع سنوية', perfNote, fmt(result.performanceBonus), 'perf-row');
  }

  if (result.specificPositionAllowance > 0) {
    addRow(`تعويض المنصب النوعي (${result.specificPositionName})`, '%', fmt(result.specificPositionAllowance), 'highlight');
  }
  if (result.snmgComplement > 0) {
    addRow('تكملة الأجر الوطني الأدنى المضمون', 'SNMG', fmt(result.snmgComplement), 'highlight');
  }

  const perfNote = result.hasPerformance
    ? `<div class="perf-note">⏰ ملاحظة: هذا الشهر يتضمن منحة المردودية (PRI) — المردودية تُصرف كل 3 أشهر (ربع سنوية)${result.absenceDays > 0 ? ` — تم خصم ${result.absenceDays} يوم غياب` : ''}</div>`
    : `<div class="no-perf-note">ℹ️ هذا الشهر بدون منحة مردودية — المردودية (PRI) تُصرف كل 3 أشهر فقط</div>`;

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>كشف الراتب ${periodLabel} - ${gradeName}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Cairo', 'Tahoma', sans-serif; }
    body { background: #f0f2f5; color: #1a1a2e; padding: 20px; direction: rtl; }
    .slip { max-width: 800px; margin: 0 auto; background: white; border: 2px solid #1e3a5f; overflow: hidden; }

    .header { background: #1e3a5f; color: white; padding: 15px 20px; text-align: center; }
    .header .flag { font-size: 24px; margin-bottom: 3px; }
    .header h1 { font-size: 14px; font-weight: 800; margin-bottom: 2px; }
    .header h2 { font-size: 12px; font-weight: 600; color: #93c5fd; }
    .header .period { font-size: 11px; color: #fbbf24; margin-top: 6px; padding: 3px 14px; background: rgba(255,255,255,0.12); display: inline-block; border-radius: 20px; font-weight: 700; }

    .info-grid { display: grid; grid-template-columns: 1fr 1fr; border-bottom: 2px solid #1e3a5f; }
    .info-cell { padding: 6px 14px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; font-size: 11px; }
    .info-cell:nth-child(odd) { border-left: 1px solid #d1d5db; }
    .info-cell .lbl { color: #6b7280; font-weight: 600; }
    .info-cell .val { font-weight: 800; color: #1e3a5f; }

    .perf-note { background: #fffbeb; padding: 6px 14px; font-size: 10px; color: #92400e; font-weight: 600; border-bottom: 1px solid #fde68a; text-align: center; }
    .no-perf-note { background: #eff6ff; padding: 6px 14px; font-size: 10px; color: #1d4ed8; font-weight: 600; border-bottom: 1px solid #bfdbfe; text-align: center; }

    .content-area { display: grid; grid-template-columns: 1.3fr 1fr; }
    .col-right { border-left: 2px solid #1e3a5f; }

    .section-title { padding: 7px 14px; font-size: 11px; font-weight: 800; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; gap: 5px; }
    .section-title.earnings { background: #ecfdf5; color: #059669; }
    .section-title.deductions { background: #fef2f2; color: #dc2626; }
    .section-title.family { background: #eff6ff; color: #2563eb; }

    table { width: 100%; border-collapse: collapse; }
    table td { padding: 4px 10px; font-size: 10px; border-bottom: 1px solid #f3f4f6; vertical-align: middle; }
    table td.num { width: 24px; text-align: center; color: #9ca3af; font-size: 9px; }
    table td:nth-child(2) { color: #374151; font-weight: 500; }
    table td.rate { color: #9ca3af; font-size: 9px; text-align: center; width: 110px; }
    table td.amount { text-align: left; font-weight: 700; color: #1e3a5f; direction: ltr; white-space: nowrap; width: 130px; }
    table tr.highlight td { background: #fffbeb; }
    table tr.perf-row td { background: #fefce8; }

    .total-row td { border-top: 2px solid #1e3a5f !important; font-weight: 900 !important; font-size: 11.5px !important; padding: 8px 10px !important; }
    .total-row.earnings td { color: #059669; }
    .total-row.deductions td { color: #dc2626; }

    .net-box { background: #1e3a5f; padding: 16px 20px; text-align: center; }
    .net-label { font-size: 11px; color: #93c5fd; font-weight: 600; }
    .net-amount { font-size: 28px; font-weight: 900; color: #34d399; direction: ltr; letter-spacing: 0.5px; margin: 4px 0; }
    .net-formula { font-size: 8.5px; color: #9ca3af; }

    .footer { padding: 8px 14px; text-align: center; font-size: 8px; color: #9ca3af; border-top: 1px solid #e5e7eb; background: #f9fafb; }
    .footer .dev { color: #1e40af; font-weight: 700; }
    .footer .warn { color: #d97706; font-weight: 600; display: block; margin-bottom: 2px; font-size: 8.5px; }

    @media print {
      body { padding: 0; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .slip { border: 2px solid #000; }
      .no-print { display: none !important; }
      @page { size: A4; margin: 10mm; }
    }
    .print-btn { display: block; margin: 12px auto; padding: 10px 28px; background: #1e3a5f; color: white; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; font-family: 'Cairo', sans-serif; }
    .print-btn:hover { background: #2563eb; }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">🖨️ طباعة الكشف</button>
  <div class="slip">
    <div class="header">
      <div class="flag">🇩🇿</div>
      <h1>الجمهورية الجزائرية الديمقراطية الشعبية</h1>
      <h2>وزارة التعليم العالي والبحث العلمي</h2>
      <div class="period">📋 ${periodTitle}</div>
    </div>

    <div class="info-grid">
      <div class="info-cell"><span class="lbl">الفئة:</span><span class="val">${getCategoryLabel(categoryType)}</span></div>
      <div class="info-cell"><span class="lbl">الرتبة:</span><span class="val">${gradeName}</span></div>
      <div class="info-cell"><span class="lbl">الصنف:</span><span class="val">${gradeCategory}</span></div>
      <div class="info-cell"><span class="lbl">الدرجة:</span><span class="val">${step}</span></div>
      <div class="info-cell"><span class="lbl">الرقم الاستدلالي:</span><span class="val">${result.indexNumber}</span></div>
      <div class="info-cell"><span class="lbl">الأقدمية:</span><span class="val">${experienceYears} سنة (${result.experienceRate}%)</span></div>
      <div class="info-cell"><span class="lbl">المنطقة:</span><span class="val">${zoneName}</span></div>
      <div class="info-cell"><span class="lbl">الحالة العائلية:</span><span class="val">${isMarried ? 'متزوج(ة)' : 'أعزب(ة)'} | ${childrenCount} أطفال</span></div>
      ${result.specificPositionName ? `<div class="info-cell" style="grid-column:1/-1;background:#fffbeb;"><span class="lbl">👑 المنصب النوعي:</span><span class="val">${result.specificPositionName}</span></div>` : ''}
    </div>

    ${!isAnnual ? perfNote : ''}

    <div class="content-area">
      <div class="col-right">
        <div class="section-title earnings">📈 المستحقات والتعويضات</div>
        <table>
          ${rows.join('\n          ')}
          <tr class="total-row earnings"><td class="num"></td><td>الراتب الإجمالي ${periodLabel}</td><td class="rate"></td><td class="amount">${fmt(result.grossSalary)}</td></tr>
        </table>
      </div>
      <div class="col-left">
        <div class="section-title deductions">📉 الاقتطاعات</div>
        <table>
          <tr><td class="num">1</td><td>اشتراك الضمان الاجتماعي</td><td class="rate">9%</td><td class="amount">${fmt(result.socialSecurity)}</td></tr>
          <tr><td class="num">2</td><td>الضريبة على الدخل (IRG)</td><td class="rate">جدول</td><td class="amount">${fmt(result.irg)}</td></tr>
          <tr class="total-row deductions"><td class="num"></td><td>مجموع الاقتطاعات</td><td class="rate"></td><td class="amount">${fmt(result.totalDeductions)}</td></tr>
        </table>

        ${(result.spouseAllowance > 0 || result.childAllowance > 0) ? `
        <div class="section-title family">👨‍👩‍👧‍👦 المنح العائلية</div>
        <table>
          ${result.spouseAllowance > 0 ? `<tr><td class="num">1</td><td>منحة الزوج (أجر وحيد)</td><td class="rate">800 د.ج</td><td class="amount">${fmt(result.spouseAllowance)}</td></tr>` : ''}
          ${result.childAllowance > 0 ? `<tr><td class="num">${result.spouseAllowance > 0 ? '2' : '1'}</td><td>منحة الأولاد (${childrenCount} × 600)</td><td class="rate">${childrenCount} × 600</td><td class="amount">${fmt(result.childAllowance)}</td></tr>` : ''}
        </table>
        ` : ''}
      </div>
    </div>

    <div class="net-box">
      <div class="net-label">💰 الراتب الصافي ${periodLabel} المستحق</div>
      <div class="net-amount">${fmt(result.netSalary)}</div>
      <div class="net-formula">
        الإجمالي (${fmt(result.grossSalary)}) - الاقتطاعات (${fmt(result.totalDeductions)})
        ${(result.spouseAllowance + result.childAllowance) > 0 ? ` + المنح العائلية (${fmt(result.spouseAllowance + result.childAllowance)})` : ''}
      </div>
    </div>

    <div class="footer">
      <span class="warn">⚠️ هذا كشف تقديري استرشادي — SNMG = ${formatCurrency(SNMG)} | قيمة النقطة = ${POINT_VALUE} د.ج — الجريدة الرسمية 2026</span>
      <p>تم الإعداد بواسطة <span class="dev">حاسبة رواتب التعليم العالي والبحث العلمي</span> — تطوير: <span class="dev">دغبوج وليد</span> — تبسة، الجزائر 🇩🇿</p>
    </div>
  </div>
</body>
</html>`;
}

export default function SalaryResult({
  result,
  gradeName,
  gradeCategory,
  step,
  experienceYears,
  categoryType,
  zoneName,
  isMarried,
  childrenCount,
}: Props) {

  const handlePrint = (isAnnual: boolean) => {
    const html = generatePrintHTML(
      result, gradeName, gradeCategory, step, experienceYears,
      categoryType, zoneName, isMarried, childrenCount, isAnnual
    );
    const printWindow = window.open('', '_blank', 'width=900,height=950');
    if (!printWindow) return;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  return (
    <div className="animate-slide-in-up space-y-4">
      {/* Header Card */}
      <div className="glass-card-dark rounded-2xl overflow-hidden">
        <div className="bg-gradient-to-l from-blue-600/30 to-purple-600/30 px-6 py-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center shadow-lg">
                <Calculator className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-bold golden-title">كشف الراتب التقديري</h3>
                <p className="text-xs font-semibold silver-title">{gradeName} (صنف {gradeCategory}) | الدرجة {step} | أقدمية {experienceYears} سنة</p>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => handlePrint(false)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white text-sm font-bold transition-all duration-300 shadow-lg shadow-green-500/25 hover:shadow-green-500/40"
              >
                <CalendarDays className="w-4 h-4" />
                <Printer className="w-4 h-4" />
                <span>طباعة شهري</span>
              </button>
              <button
                onClick={() => handlePrint(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-sm font-bold transition-all duration-300 shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40"
              >
                <CalendarRange className="w-4 h-4" />
                <Printer className="w-4 h-4" />
                <span>طباعة سنوي</span>
              </button>
            </div>
          </div>
        </div>

        {/* Index Info */}
        <div className="px-6 py-3 flex flex-wrap gap-4 border-b border-white/5">
          <div className="flex items-center gap-2 text-sm">
            <Award className="w-4 h-4 text-blue-400" />
            <span className="silver-title font-medium">الرقم الاستدلالي:</span>
             <span className="text-white font-bold bg-blue-500/20 px-2 py-0.5 rounded">{result.indexNumber}</span>
           </div>
           <div className="flex items-center gap-2 text-sm">
             <TrendingUp className="w-4 h-4 text-emerald-400" />
             <span className="silver-title font-medium">نسبة الخبرة:</span>
             <span className="text-emerald-400 font-bold">{result.experienceRate}%</span>
           </div>
           <div className="flex items-center gap-2 text-sm">
             <MapPin className="w-4 h-4 text-amber-400" />
             <span className="silver-title font-medium">المنطقة:</span>
             <span className="text-amber-400 font-bold">{zoneName}</span>
           </div>
          {isMarried && (
            <div className="flex items-center gap-2 text-sm">
              <Heart className="w-4 h-4 text-red-400" />
              <span className="text-red-400 font-bold">متزوج(ة)</span>
            </div>
          )}
          {childrenCount > 0 && (
            <div className="flex items-center gap-2 text-sm">
              <Baby className="w-4 h-4 text-pink-400" />
              <span className="text-pink-400 font-bold">{childrenCount} أطفال</span>
            </div>
          )}
          {result.specificPositionName && (
            <div className="flex items-center gap-2 text-sm">
              <Crown className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-400 font-bold">{result.specificPositionName}</span>
            </div>
          )}
        </div>

        {/* Performance status indicator */}
        {result.hasPerformance ? (
          <div className="px-6 py-2 bg-amber-500/10 border-b border-amber-500/15 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-xs text-amber-300 font-bold">
              ⏰ شهر مردودية — المردودية (PRI) تُصرف ربع سنويًا بنسبة {result.performanceRate}%
              {result.absenceDays > 0 && ` — تم خصم ${result.absenceDays} يوم غياب`}
            </span>
          </div>
        ) : (
          <div className="px-6 py-2 bg-blue-500/10 border-b border-blue-500/15 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-400" />
            <span className="text-xs text-blue-300 font-bold">
              ℹ️ شهر بدون مردودية — المردودية (PRI) تُصرف كل 3 أشهر فقط
            </span>
          </div>
        )}
      </div>

      {/* Earnings Section */}
      <div className="glass-card-dark rounded-2xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-3 bg-yellow-500/10 border-b border-yellow-500/20">
          <TrendingUp className="w-4 h-4 text-yellow-400" />
          <h4 className="text-sm font-bold golden-title">المستحقات والتعويضات</h4>
        </div>
        <div className="p-4 space-y-0.5">
          <SalaryRow label="الراتب الأساسي" value={result.baseSalary} type="positive"
            icon={<Banknote className="w-4 h-4" />}
            rate={`${result.indexNumber} × ${POINT_VALUE} د.ج`} />
          <SalaryRow label="تعويض الخبرة المهنية" value={result.experienceAllowance} type="positive"
            icon={<TrendingUp className="w-4 h-4" />} rate={`${result.experienceRate}%`} />
          {result.pedagogicalAllowance > 0 && (
            <SalaryRow label="التعويض البيداغوجي" value={result.pedagogicalAllowance} type="positive"
              icon={<BookOpen className="w-4 h-4" />} />
          )}
          {result.qualificationAllowance > 0 && (
            <SalaryRow label="تعويض التأهيل" value={result.qualificationAllowance} type="positive"
              icon={<Award className="w-4 h-4" />} />
          )}
          {result.documentationAllowance > 0 && (
            <SalaryRow label="منحة التوثيق" value={result.documentationAllowance} type="positive"
              icon={<FileText className="w-4 h-4" />} rate="مبلغ ثابت" />
          )}
          <SalaryRow label="المنحة الخاصة بالمنصب" value={result.specificAllowance} type="positive"
            icon={<FileText className="w-4 h-4" />} />
          {result.supervisionAllowance > 0 && (
            <SalaryRow label="منحة التأطير" value={result.supervisionAllowance} type="positive"
              icon={<Crown className="w-4 h-4" />} />
          )}
          {result.riskAllowance > 0 && (
            <SalaryRow label="تعويض الضرر" value={result.riskAllowance} type="positive"
              icon={<Shield className="w-4 h-4" />} />
          )}
          {result.zoneAllowance > 0 && (
            <SalaryRow label="تعويض المنطقة" value={result.zoneAllowance} type="positive"
              icon={<MapPin className="w-4 h-4" />} />
          )}

          {/* Performance - Quarterly */}
          {result.hasPerformance && (
            <div className="border-t border-amber-500/15 mt-1 pt-1">
              <SalaryRow
                label={result.absenceDays > 0
                  ? `منحة المردودية الربع سنوية (${result.effectiveWorkDays}/22 يوم)`
                  : 'منحة المردودية الربع سنوية (PRI)'}
                value={result.performanceBonus} type="positive"
                icon={<TrendingUp className="w-4 h-4" />}
                rate={`${result.performanceRate}%`}
              />
              {result.absenceDays > 0 && (
                <div className="px-3 pb-1">
                  <span className="text-xs text-orange-400 bg-orange-500/10 px-2 py-1 rounded-lg">
                    ⚠️ تم خصم {result.absenceDays} يوم غياب — أيام العمل الفعلية: {result.effectiveWorkDays}/22
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Specific Position */}
          {result.specificPositionAllowance > 0 && (
            <div className="border-t border-yellow-500/20 mt-1 pt-1">
              <SalaryRow
                label={`تعويض المنصب النوعي (${result.specificPositionName})`}
                value={result.specificPositionAllowance} type="positive"
                icon={<Crown className="w-4 h-4 text-yellow-400" />}
              />
            </div>
          )}

          {/* SNMG Complement */}
          {result.snmgComplement > 0 && (
            <div className="border-t border-blue-500/20 mt-1 pt-1">
              <SalaryRow
                label="تكملة الأجر الوطني الأدنى المضمون (SNMG)"
                value={result.snmgComplement} type="positive"
                icon={<Shield className="w-4 h-4 text-blue-400" />}
                rate={`${formatCurrency(SNMG)}`}
              />
            </div>
          )}

          <div className="border-t border-white/10 mt-2 pt-2">
            <SalaryRow label="الراتب الإجمالي" value={result.grossSalary} type="total" />
          </div>
        </div>
      </div>

      {/* Deductions Section */}
      <div className="glass-card-dark rounded-2xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-3 bg-yellow-500/10 border-b border-yellow-500/20">
          <TrendingDown className="w-4 h-4 text-yellow-400" />
          <h4 className="text-sm font-bold golden-title">الاقتطاعات</h4>
        </div>
        <div className="p-4 space-y-0.5">
          <SalaryRow label="اشتراك الضمان الاجتماعي" value={result.socialSecurity} type="negative"
            icon={<Shield className="w-4 h-4" />} rate="9%" />
          <SalaryRow label="الضريبة على الدخل IRG" value={result.irg} type="negative"
            icon={<FileText className="w-4 h-4" />} />
          <div className="border-t border-white/10 mt-2 pt-2">
            <SalaryRow label="مجموع الاقتطاعات" value={result.totalDeductions} type="negative" />
          </div>
        </div>
      </div>

      {/* Family Allowances Section */}
      {(result.spouseAllowance > 0 || result.childAllowance > 0) && (
        <div className="glass-card-dark rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-3 bg-yellow-500/10 border-b border-yellow-500/20">
            <Heart className="w-4 h-4 text-yellow-400" />
            <h4 className="text-sm font-bold golden-title">المنح العائلية</h4>
          </div>
          <div className="p-4 space-y-0.5">
            {result.spouseAllowance > 0 && (
              <SalaryRow label="منحة الزوج (الأجر الوحيد)" value={result.spouseAllowance} type="positive"
                icon={<Heart className="w-4 h-4" />} rate="800 د.ج" />
            )}
            {result.childAllowance > 0 && (
              <SalaryRow label={`المنح العائلية (${childrenCount} أطفال × 600 د.ج)`}
                value={result.childAllowance} type="positive"
                icon={<Baby className="w-4 h-4" />} />
            )}
          </div>
        </div>
      )}

      {/* Net Salary */}
      <div className="relative overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-l from-emerald-600/30 via-blue-600/30 to-purple-600/30 animate-gradient" style={{ backgroundSize: '400% 400%' }} />
        <div className="glass-card-dark rounded-2xl p-6 relative z-10 border-2 border-emerald-500/30">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-500 flex items-center justify-center shadow-lg shadow-emerald-500/30 animate-pulse">
                <Banknote className="w-7 h-7 text-white" />
              </div>
              <div>
                <p className="golden-title text-sm font-bold">
                  الراتب الصافي الشهري المستحق
                  {result.hasPerformance && <span className="text-amber-400 text-xs mr-1">(+ مردودية)</span>}
                </p>
                <p className="text-xs font-medium silver-title">بعد خصم الاقتطاعات + المنح العائلية</p>
              </div>
            </div>
            <div className="text-3xl md:text-4xl font-black golden-title-lg" dir="ltr">
              {formatCurrency(result.netSalary)}
            </div>
          </div>

          {/* Annual display */}
          <div className="mt-4 pt-4 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-purple-500 to-violet-500 flex items-center justify-center">
                <CalendarRange className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="golden-title text-xs font-bold">الراتب الصافي السنوي التقديري</p>
                 <p className="text-xs font-medium silver-title">12 شهراً</p>
              </div>
            </div>
            <div className="text-xl md:text-2xl font-bold golden-title" dir="ltr">
              {formatCurrency(result.netSalary * 12)}
            </div>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center">
        <p className="text-xs text-amber-300/80">
          ⚠️ هذا كشف تقديري استرشادي — قيمة النقطة الاستدلالية: {POINT_VALUE} د.ج | SNMG = {formatCurrency(SNMG)} — الجريدة الرسمية 2026 — وقد تختلف القيم الفعلية حسب الوضعية الإدارية الفعلية للموظف
        </p>
        <p className="text-xs text-blue-300/70 mt-1">
          ℹ️ المردودية (PRI) تُحسب وتُصرف كل ثلاثة أشهر (ربع سنوية) وليست شهرية
        </p>
      </div>
    </div>
  );
}
