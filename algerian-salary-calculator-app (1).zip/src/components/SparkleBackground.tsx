import { useEffect, useState } from 'react';

interface Sparkle {
  id: number;
  x: number;
  y: number;
  size: number;
  delay: number;
  duration: number;
  opacity: number;
}

interface FloatingOrb {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  delay: number;
  duration: number;
}

export default function SparkleBackground() {
  const [sparkles, setSparkles] = useState<Sparkle[]>([]);
  const [orbs, setOrbs] = useState<FloatingOrb[]>([]);

  useEffect(() => {
    const newSparkles: Sparkle[] = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      delay: Math.random() * 5,
      duration: Math.random() * 3 + 2,
      opacity: Math.random() * 0.7 + 0.3,
    }));
    setSparkles(newSparkles);

    const colors = [
      'rgba(59, 130, 246, 0.15)',
      'rgba(16, 185, 129, 0.12)',
      'rgba(139, 92, 246, 0.1)',
      'rgba(245, 158, 11, 0.08)',
      'rgba(236, 72, 153, 0.08)',
    ];

    const newOrbs: FloatingOrb[] = Array.from({ length: 8 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 300 + 100,
      color: colors[i % colors.length],
      delay: Math.random() * 5,
      duration: Math.random() * 10 + 10,
    }));
    setOrbs(newOrbs);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 0 }}>
      {/* Gradient base */}
      <div
        className="absolute inset-0 animate-gradient"
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 25%, #0f172a 50%, #1a2332 75%, #0f172a 100%)',
          backgroundSize: '400% 400%',
        }}
      />

      {/* Floating orbs */}
      {orbs.map(orb => (
        <div
          key={`orb-${orb.id}`}
          className="absolute rounded-full"
          style={{
            left: `${orb.x}%`,
            top: `${orb.y}%`,
            width: `${orb.size}px`,
            height: `${orb.size}px`,
            background: `radial-gradient(circle, ${orb.color} 0%, transparent 70%)`,
            animation: `float ${orb.duration}s ease-in-out ${orb.delay}s infinite`,
            filter: 'blur(40px)',
          }}
        />
      ))}

      {/* Sparkle particles */}
      {sparkles.map(sparkle => (
        <div
          key={`sparkle-${sparkle.id}`}
          className="absolute rounded-full"
          style={{
            left: `${sparkle.x}%`,
            top: `${sparkle.y}%`,
            width: `${sparkle.size}px`,
            height: `${sparkle.size}px`,
            background: `radial-gradient(circle, rgba(255,255,255,${sparkle.opacity}) 0%, transparent 70%)`,
            animation: `sparkle ${sparkle.duration}s ease-in-out ${sparkle.delay}s infinite`,
            boxShadow: `0 0 ${sparkle.size * 2}px rgba(255,255,255,${sparkle.opacity * 0.5})`,
          }}
        />
      ))}

      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px',
        }}
      />
    </div>
  );
}
