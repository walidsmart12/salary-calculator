// بيانات الرواتب حسب الجريدة الرسمية 2026
// قطاع التعليم العالي والبحث العلمي - الجزائر
// تحديث: وفق سلم الأجور الجديد - الأجر الوطني الأدنى المضمون 24,000 د.ج

// الأجر الوطني الأدنى المضمون (SNMG)
export const SNMG = 24000;

// قيمة النقطة الاستدلالية الرسمية (المرسوم الرئاسي 07-304)
export const POINT_VALUE = 45;

// الأرقام الاستدلالية الدنيا حسب الأصناف (الشبكة الاستدلالية - المرسوم الرئاسي 07-304)
export const CATEGORY_MIN_INDEX: Record<number, number> = {
  1: 200, 2: 222, 3: 247, 4: 274, 5: 304,
  6: 337, 7: 374, 8: 416, 9: 462, 10: 513,
  11: 570, 12: 620, 13: 688, 14: 764, 15: 848,
  16: 941, 17: 1045, 18: 1160, 19: 1288, 20: 1430,
};

// الزيادة في الرقم الاستدلالي حسب الدرجة لكل صنف (المرسوم الرئاسي 07-304)
export const STEP_INCREMENT: Record<number, number> = {
  1: 12, 2: 15, 3: 17, 4: 20, 5: 22,
  6: 25, 7: 28, 8: 32, 9: 35, 10: 39,
  11: 43, 12: 47, 13: 52, 14: 58, 15: 64,
  16: 71, 17: 79, 18: 88, 19: 98, 20: 109,
};

// أنواع الموظفين
export type EmployeeCategory = 'professor' | 'admin' | 'technician' | 'researcher';

export interface Grade {
  id: string;
  name: string;
  category: number;
  section: number;
  documentationAllowance: number;
  pedagogicalAllowance: number;
  qualificationAllowance: number;
  specificAllowance: number;
  supervisionAllowance: number;
  riskAllowance: number;
}

// المناصب النوعية
export interface SpecificPosition {
  id: string;
  name: string;
  rate: number;
  forCategory: EmployeeCategory[];
}

export const SPECIFIC_POSITIONS: SpecificPosition[] = [
  { id: 'none', name: 'بدون منصب نوعي', rate: 0, forCategory: ['professor', 'researcher', 'admin', 'technician'] },
  { id: 'dept_head', name: 'رئيس قسم', rate: 30, forCategory: ['professor', 'researcher'] },
  { id: 'vice_dean', name: 'نائب عميد', rate: 35, forCategory: ['professor', 'researcher'] },
  { id: 'dean', name: 'عميد كلية', rate: 40, forCategory: ['professor', 'researcher'] },
  { id: 'vice_rector', name: 'نائب رئيس الجامعة', rate: 45, forCategory: ['professor', 'researcher'] },
  { id: 'rector', name: 'رئيس الجامعة', rate: 55, forCategory: ['professor', 'researcher'] },
  { id: 'lab_director', name: 'مدير مخبر بحث', rate: 25, forCategory: ['professor', 'researcher'] },
  { id: 'team_leader', name: 'رئيس فرقة بحث', rate: 15, forCategory: ['professor', 'researcher'] },
  { id: 'resp_formation', name: 'مسؤول تكوين', rate: 20, forCategory: ['professor'] },
  { id: 'resp_domaine', name: 'مسؤول ميدان', rate: 20, forCategory: ['professor'] },
  { id: 'service_head', name: 'رئيس مصلحة', rate: 20, forCategory: ['admin', 'technician'] },
  { id: 'sub_director', name: 'مدير فرعي', rate: 25, forCategory: ['admin'] },
  { id: 'director', name: 'مدير', rate: 30, forCategory: ['admin'] },
  { id: 'secretary_general', name: 'أمين عام', rate: 35, forCategory: ['admin'] },
  { id: 'lab_head', name: 'رئيس ورشة / مخبر', rate: 15, forCategory: ['technician'] },
  { id: 'tech_service', name: 'رئيس مصلحة تقنية', rate: 20, forCategory: ['technician'] },
];

// ============================================
// رتب الأساتذة الباحثين
// ============================================
export const PROFESSOR_GRADES: Grade[] = [
  {
    id: 'prof_assistant_b',
    name: 'أستاذ مساعد قسم (ب)',
    category: 12,
    section: 3,
    documentationAllowance: 4000,
    pedagogicalAllowance: 25,
    qualificationAllowance: 25,
    specificAllowance: 15,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'prof_assistant_a',
    name: 'أستاذ مساعد قسم (أ)',
    category: 13,
    section: 3,
    documentationAllowance: 5000,
    pedagogicalAllowance: 25,
    qualificationAllowance: 30,
    specificAllowance: 15,
    supervisionAllowance: 5,
    riskAllowance: 0,
  },
  {
    id: 'prof_lecturer_b',
    name: 'أستاذ محاضر قسم (ب)',
    category: 14,
    section: 3,
    documentationAllowance: 6000,
    pedagogicalAllowance: 30,
    qualificationAllowance: 35,
    specificAllowance: 20,
    supervisionAllowance: 10,
    riskAllowance: 0,
  },
  {
    id: 'prof_lecturer_a',
    name: 'أستاذ محاضر قسم (أ)',
    category: 15,
    section: 3,
    documentationAllowance: 7500,
    pedagogicalAllowance: 30,
    qualificationAllowance: 40,
    specificAllowance: 20,
    supervisionAllowance: 15,
    riskAllowance: 0,
  },
  {
    id: 'prof_higher_education',
    name: 'أستاذ التعليم العالي',
    category: 16,
    section: 3,
    documentationAllowance: 10000,
    pedagogicalAllowance: 35,
    qualificationAllowance: 50,
    specificAllowance: 25,
    supervisionAllowance: 25,
    riskAllowance: 0,
  },
  {
    id: 'prof_chief',
    name: 'أستاذ رئيسي في التعليم العالي',
    category: 17,
    section: 4,
    documentationAllowance: 12000,
    pedagogicalAllowance: 40,
    qualificationAllowance: 55,
    specificAllowance: 30,
    supervisionAllowance: 30,
    riskAllowance: 0,
  },
  {
    id: 'prof_emeritus',
    name: 'أستاذ ممتاز',
    category: 18,
    section: 4,
    documentationAllowance: 15000,
    pedagogicalAllowance: 45,
    qualificationAllowance: 60,
    specificAllowance: 35,
    supervisionAllowance: 35,
    riskAllowance: 0,
  },
];

// ============================================
// رتب الموظفين الإداريين (الأسلاك المشتركة)
// محدث وفق التصنيف الرسمي الصحيح
// ============================================
export const ADMIN_GRADES: Grade[] = [
  {
    id: 'admin_agent',
    name: 'عون إدارة',
    category: 3,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_data_entry',
    name: 'عون حفظ البيانات',
    category: 4,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_agent_principal',
    name: 'عون إدارة رئيسي',
    category: 5,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_data_principal',
    name: 'عون حفظ البيانات رئيسي',
    category: 6,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_secretary',
    name: 'كاتب إدارة',
    category: 6,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_accountant',
    name: 'محاسب إداري',
    category: 7,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 5,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_secretary_dir',
    name: 'كاتب مديرية',
    category: 8,
    section: 2,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 10,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_attach',
    name: 'ملحق إدارة',
    category: 9,
    section: 2,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 10,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'admin_attach_principal',
    name: 'ملحق رئيسي للإدارة',
    category: 10,
    section: 2,
    documentationAllowance: 1500,
    pedagogicalAllowance: 0,
    qualificationAllowance: 15,
    specificAllowance: 10,
    supervisionAllowance: 5,
    riskAllowance: 0,
  },
  {
    id: 'admin_manager',
    name: 'متصرف إداري',
    category: 12,
    section: 3,
    documentationAllowance: 2500,
    pedagogicalAllowance: 0,
    qualificationAllowance: 20,
    specificAllowance: 12,
    supervisionAllowance: 10,
    riskAllowance: 0,
  },
  {
    id: 'admin_manager_principal',
    name: 'متصرف رئيسي',
    category: 14,
    section: 3,
    documentationAllowance: 3500,
    pedagogicalAllowance: 0,
    qualificationAllowance: 25,
    specificAllowance: 15,
    supervisionAllowance: 15,
    riskAllowance: 0,
  },
  {
    id: 'admin_counselor',
    name: 'متصرف مستشار',
    category: 16,
    section: 4,
    documentationAllowance: 5000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 30,
    specificAllowance: 20,
    supervisionAllowance: 20,
    riskAllowance: 0,
  },
];

// ============================================
// رتب التقنيين والمهندسين والمخبريين
// ============================================
export const TECHNICIAN_GRADES: Grade[] = [
  {
    id: 'tech_agent',
    name: 'عون تقني',
    category: 4,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 5,
  },
  {
    id: 'tech_lab_agent',
    name: 'عون مخبر',
    category: 5,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 12,
    supervisionAllowance: 0,
    riskAllowance: 5,
  },
  {
    id: 'tech_agent_principal',
    name: 'عون تقني رئيسي',
    category: 6,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 0,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 5,
  },
  {
    id: 'tech_technician',
    name: 'تقني',
    category: 7,
    section: 1,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 5,
    specificAllowance: 10,
    supervisionAllowance: 0,
    riskAllowance: 5,
  },
  {
    id: 'tech_superior',
    name: 'تقني سامي',
    category: 9,
    section: 2,
    documentationAllowance: 0,
    pedagogicalAllowance: 0,
    qualificationAllowance: 10,
    specificAllowance: 12,
    supervisionAllowance: 0,
    riskAllowance: 5,
  },
  {
    id: 'tech_superior_principal',
    name: 'تقني سامي رئيسي',
    category: 10,
    section: 2,
    documentationAllowance: 1000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 15,
    specificAllowance: 12,
    supervisionAllowance: 5,
    riskAllowance: 5,
  },
  {
    id: 'tech_engineer_applied',
    name: 'مهندس تطبيقي',
    category: 10,
    section: 2,
    documentationAllowance: 1500,
    pedagogicalAllowance: 0,
    qualificationAllowance: 15,
    specificAllowance: 12,
    supervisionAllowance: 5,
    riskAllowance: 5,
  },
  {
    id: 'tech_engineer_state',
    name: 'مهندس دولة',
    category: 12,
    section: 3,
    documentationAllowance: 2500,
    pedagogicalAllowance: 0,
    qualificationAllowance: 25,
    specificAllowance: 15,
    supervisionAllowance: 10,
    riskAllowance: 5,
  },
  {
    id: 'tech_engineer_principal',
    name: 'مهندس رئيسي',
    category: 13,
    section: 3,
    documentationAllowance: 3000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 30,
    specificAllowance: 15,
    supervisionAllowance: 15,
    riskAllowance: 5,
  },
];

// ============================================
// رتب الباحثين الدائمين
// ============================================
export const RESEARCHER_GRADES: Grade[] = [
  {
    id: 'res_attach',
    name: 'ملحق بحث',
    category: 12,
    section: 3,
    documentationAllowance: 4000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 25,
    specificAllowance: 15,
    supervisionAllowance: 0,
    riskAllowance: 0,
  },
  {
    id: 'res_charge',
    name: 'مكلف بالبحث',
    category: 13,
    section: 3,
    documentationAllowance: 5000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 30,
    specificAllowance: 15,
    supervisionAllowance: 5,
    riskAllowance: 0,
  },
  {
    id: 'res_master_b',
    name: 'أستاذ بحث قسم (ب)',
    category: 14,
    section: 3,
    documentationAllowance: 6000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 35,
    specificAllowance: 20,
    supervisionAllowance: 10,
    riskAllowance: 0,
  },
  {
    id: 'res_master_a',
    name: 'أستاذ بحث قسم (أ)',
    category: 15,
    section: 3,
    documentationAllowance: 7500,
    pedagogicalAllowance: 0,
    qualificationAllowance: 40,
    specificAllowance: 20,
    supervisionAllowance: 15,
    riskAllowance: 0,
  },
  {
    id: 'res_director',
    name: 'مدير بحث',
    category: 16,
    section: 3,
    documentationAllowance: 10000,
    pedagogicalAllowance: 0,
    qualificationAllowance: 50,
    specificAllowance: 25,
    supervisionAllowance: 25,
    riskAllowance: 0,
  },
];

// ============================================
// نسب الخبرة المهنية حسب الأقدمية
// ============================================
export const EXPERIENCE_RATES: { minYears: number; maxYears: number; rate: number }[] = [
  { minYears: 0, maxYears: 1, rate: 0 },
  { minYears: 1, maxYears: 3, rate: 5 },
  { minYears: 3, maxYears: 5, rate: 10 },
  { minYears: 5, maxYears: 7, rate: 15 },
  { minYears: 7, maxYears: 10, rate: 20 },
  { minYears: 10, maxYears: 15, rate: 28 },
  { minYears: 15, maxYears: 20, rate: 36 },
  { minYears: 20, maxYears: 25, rate: 44 },
  { minYears: 25, maxYears: 30, rate: 52 },
  { minYears: 30, maxYears: 35, rate: 60 },
  { minYears: 35, maxYears: 99, rate: 68 },
];

// ============================================
// جدول الضريبة على الدخل الإجمالي IRG (محدث 2026)
// وفق جدول IRG الجديد مع إعفاء حتى 30,000 د.ج
// ============================================
export function calculateIRG(taxableIncome: number): number {
  if (taxableIncome <= 30000) return 0;

  if (taxableIncome <= 35000) {
    const rate = ((taxableIncome - 30000) / 5000) * 0.20;
    return Math.round(taxableIncome * rate * 0.5);
  }

  let tax = 0;

  if (taxableIncome <= 120000) {
    tax = (taxableIncome - 30000) * 0.20;
  } else if (taxableIncome <= 240000) {
    tax = (120000 - 30000) * 0.20 + (taxableIncome - 120000) * 0.30;
  } else if (taxableIncome <= 480000) {
    tax = (120000 - 30000) * 0.20 + (240000 - 120000) * 0.30 + (taxableIncome - 240000) * 0.35;
  } else {
    tax = (120000 - 30000) * 0.20 + (240000 - 120000) * 0.30 + (480000 - 240000) * 0.35 + (taxableIncome - 480000) * 0.35;
  }

  let abattement = tax * 0.40;
  if (abattement < 1000) abattement = 1000;
  if (abattement > 1500) abattement = 1500;

  tax = tax - abattement;
  return Math.max(0, Math.round(tax));
}

// نسبة اقتطاع الضمان الاجتماعي
export const SOCIAL_SECURITY_RATE = 9;
export const EMPLOYER_SS_RATE = 26;

// منحة الزوج (الأجر الوحيد)
export const SPOUSE_ALLOWANCE = 800;
// منحة الأولاد
export const CHILD_ALLOWANCE = 600;

// عدد أيام العمل في الشهر
export const WORKING_DAYS_PER_MONTH = 22;

// المناطق الجغرافية
export const ZONES = [
  { id: 'zone1', name: 'المنطقة الأولى (الشمال)', rate: 0 },
  { id: 'zone2', name: 'المنطقة الثانية (الهضاب العليا)', rate: 5 },
  { id: 'zone3', name: 'المنطقة الثالثة (الجنوب)', rate: 10 },
  { id: 'zone4', name: 'المنطقة الرابعة (الجنوب الكبير)', rate: 15 },
];

// حساب الرقم الاستدلالي
export function calculateIndex(category: number, step: number): number {
  const minIndex = CATEGORY_MIN_INDEX[category] || 200;
  const increment = STEP_INCREMENT[category] || 12;
  return minIndex + (step * increment);
}

// حساب الراتب الأساسي
export function calculateBaseSalary(indexNumber: number): number {
  return indexNumber * POINT_VALUE;
}

// واجهة نتيجة حساب الراتب
export interface SalaryResult {
  indexNumber: number;
  baseSalary: number;
  experienceAllowance: number;
  experienceRate: number;
  pedagogicalAllowance: number;
  qualificationAllowance: number;
  documentationAllowance: number;
  specificAllowance: number;
  supervisionAllowance: number;
  riskAllowance: number;
  zoneAllowance: number;
  performanceBonus: number;
  performanceRate: number;
  hasPerformance: boolean;
  absenceDays: number;
  effectiveWorkDays: number;
  specificPositionAllowance: number;
  specificPositionName: string;
  snmgComplement: number;
  grossSalary: number;
  socialSecurity: number;
  taxableIncome: number;
  irg: number;
  spouseAllowance: number;
  childAllowance: number;
  totalDeductions: number;
  netSalary: number;
}

// حساب الراتب الكامل
export function calculateFullSalary(
  grade: Grade,
  step: number,
  experienceYears: number,
  zoneRate: number,
  hasPerformance: boolean,
  performanceRate: number,
  absenceDays: number,
  isMarried: boolean,
  childrenCount: number,
  specificPositionRate: number,
  specificPositionName: string,
): SalaryResult {
  const indexNumber = calculateIndex(grade.category, step);
  const baseSalary = calculateBaseSalary(indexNumber);

  const experienceBracket = EXPERIENCE_RATES.find(
    b => experienceYears >= b.minYears && experienceYears < b.maxYears
  );
  const experienceRate = experienceBracket?.rate || 0;
  const experienceAllowance = Math.round((baseSalary * experienceRate) / 100);

  const pedagogicalAllowance = Math.round((baseSalary * grade.pedagogicalAllowance) / 100);
  const qualificationAllowance = Math.round((baseSalary * grade.qualificationAllowance) / 100);
  const documentationAllowance = grade.documentationAllowance;
  const specificAllowance = Math.round((baseSalary * grade.specificAllowance) / 100);
  const supervisionAllowance = Math.round((baseSalary * grade.supervisionAllowance) / 100);
  const riskAllowance = Math.round((baseSalary * grade.riskAllowance) / 100);
  const zoneAllowance = Math.round((baseSalary * zoneRate) / 100);

  // حساب المردودية (ربع سنوية - اختيارية)
  let performanceBonus = 0;
  let effectiveWorkDays = WORKING_DAYS_PER_MONTH;
  if (hasPerformance) {
    effectiveWorkDays = Math.max(0, WORKING_DAYS_PER_MONTH - absenceDays);
    const fullPerformance = Math.round((baseSalary * performanceRate) / 100);
    performanceBonus = Math.round(fullPerformance * (effectiveWorkDays / WORKING_DAYS_PER_MONTH));
  }

  // تعويض المنصب النوعي
  const specificPositionAllowance = Math.round((baseSalary * specificPositionRate) / 100);

  let grossSalary = baseSalary + experienceAllowance + pedagogicalAllowance +
    qualificationAllowance + documentationAllowance + specificAllowance +
    supervisionAllowance + riskAllowance + zoneAllowance + performanceBonus +
    specificPositionAllowance;

  // تكملة الأجر الوطني الأدنى المضمون
  let snmgComplement = 0;
  if (grossSalary < SNMG) {
    snmgComplement = SNMG - grossSalary;
    grossSalary = SNMG;
  }

  const socialSecurity = Math.round((grossSalary * SOCIAL_SECURITY_RATE) / 100);
  const taxableIncome = grossSalary - socialSecurity;
  const irg = calculateIRG(taxableIncome);

  const spouseAllowance = isMarried ? SPOUSE_ALLOWANCE : 0;
  const childAllowance = childrenCount * CHILD_ALLOWANCE;

  const totalDeductions = socialSecurity + irg;
  const netSalary = grossSalary - totalDeductions + childAllowance + spouseAllowance;

  return {
    indexNumber,
    baseSalary,
    experienceAllowance,
    experienceRate,
    pedagogicalAllowance,
    qualificationAllowance,
    documentationAllowance,
    specificAllowance,
    supervisionAllowance,
    riskAllowance,
    zoneAllowance,
    performanceBonus,
    performanceRate: hasPerformance ? performanceRate : 0,
    hasPerformance,
    absenceDays: hasPerformance ? absenceDays : 0,
    effectiveWorkDays,
    specificPositionAllowance,
    specificPositionName,
    snmgComplement,
    grossSalary,
    socialSecurity,
    taxableIncome,
    irg,
    spouseAllowance,
    childAllowance,
    totalDeductions,
    netSalary,
  };
}

export function getGradesByCategory(category: EmployeeCategory): Grade[] {
  switch (category) {
    case 'professor': return PROFESSOR_GRADES;
    case 'admin': return ADMIN_GRADES;
    case 'technician': return TECHNICIAN_GRADES;
    case 'researcher': return RESEARCHER_GRADES;
    default: return [];
  }
}

export function getCategoryLabel(category: EmployeeCategory): string {
  switch (category) {
    case 'professor': return 'أستاذ باحث';
    case 'admin': return 'إداري';
    case 'technician': return 'تقني / مهندس';
    case 'researcher': return 'باحث دائم';
    default: return '';
  }
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('ar-DZ', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount) + ' د.ج';
}
