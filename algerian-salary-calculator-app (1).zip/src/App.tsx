import { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Info,
  X,
  Scale,
  Landmark,
  Sparkles,
} from 'lucide-react';
import SparkleBackground from './components/SparkleBackground';
import SalaryCalculator from './components/SalaryCalculator';
import DeveloperInfo from './components/DeveloperInfo';

function InfoModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg glass-card-dark rounded-2xl p-6 animate-slide-in-up max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 left-4 w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-gray-400 hover:text-white transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-600 flex items-center justify-center shadow-lg shadow-yellow-500/30">
            <Info className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-lg font-bold golden-title">حول البرنامج</h2>
          
        </div>

        <div className="space-y-4 text-sm text-gray-300 leading-relaxed">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
            <Scale className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <p>
              برنامج حساب الرواتب لموظفي قطاع التعليم العالي والبحث العلمي بالجزائر،
              مبني وفق آخر التعديلات الصادرة بالجريدة الرسمية لسنة 2026.
            </p>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
            <BookOpen className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-bold silver-title-lg mb-1">المراجع القانونية:</p>
               <ul className="space-y-1 text-xs list-disc list-inside text-gray-400">
                <li>المرسوم الرئاسي المتعلق بالشبكة الاستدلالية لمرتبات الموظفين</li>
                <li>القانون الأساسي الخاص بالأستاذ الباحث</li>
                <li>المرسوم التنفيذي المحدد لعناصر الراتب</li>
                <li>قانون الضريبة على الدخل الإجمالي المحدّث</li>
                <li>الأجر الوطني الأدنى المضمون: 24,000 د.ج</li>
                <li>قيمة النقطة الاستدلالية: 45 د.ج (المرسوم الرئاسي 07-304)</li>
              </ul>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
            <Landmark className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-bold silver-title-lg mb-1">الفئات المدعومة:</p>
              <ul className="space-y-1 text-xs text-gray-400">
                <li>🎓 الأساتذة الجامعيون بمختلف الرتب</li>
                <li>🔬 الباحثون الدائمون</li>
                <li>💼 الموظفون الإداريون</li>
                <li>🔧 التقنيون والمهندسون</li>
              </ul>
              <p className="font-bold silver-title-lg mt-3 mb-1">المزايا:</p>
              <ul className="space-y-1 text-xs text-gray-400">
                <li>👑 حساب المنصب النوعي</li>
                <li>📊 حساب المردودية الربع سنوية (اختيارية) مع أيام الغياب</li>
                <li>🖨️ طباعة كشف شهري وسنوي</li>
                <li>💰 SNMG = 24,000 د.ج</li>
              </ul>
            </div>
          </div>

          <p className="text-xs text-gray-500 text-center pt-2">
            ⚠️ هذا البرنامج للاستعمال الاسترشادي فقط وقد تختلف النتائج عن الراتب الفعلي
          </p>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [showInfo, setShowInfo] = useState(false);

  return (
    <div className="relative min-h-screen" dir="rtl">
      <SparkleBackground />

      <div className="relative z-10 min-h-screen">
        {/* Header */}
        <header className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-yellow-600/10 via-transparent to-transparent" />
          <div className="relative max-w-4xl mx-auto px-4 pt-6 pb-4 md:pt-10 md:pb-6">
            {/* Top bar */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-600 to-green-800 border-2 border-yellow-500/50 flex items-center justify-center shadow-lg shadow-green-500/20">
                  <span className="text-lg">🇩🇿</span>
                </div>
                <div className="hidden sm:block">
                  <span className="text-sm font-bold golden-title">الجمهورية الجزائرية</span>
                  <br />
                  <span className="text-xs font-semibold silver-title">الديمقراطية الشعبية</span>
                </div>
              </div>
              <button
                onClick={() => setShowInfo(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-yellow-300 hover:bg-yellow-500/20 hover:text-yellow-200 transition-all duration-300 text-sm"
              >
                <Info className="w-4 h-4" />
                <span className="hidden sm:inline">حول البرنامج</span>
              </button>
            </div>

            {/* Main Title */}
            <div className="text-center space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-300 text-xs font-medium animate-pulse">
                <Sparkles className="w-3.5 h-3.5" />
                <span>محدّث وفق الجريدة الرسمية 2026</span>
                <Sparkles className="w-3.5 h-3.5" />
              </div>

              <div className="flex items-center justify-center gap-4">
                <div className="hidden md:flex w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-500/20 to-amber-600/20 border border-yellow-500/30 items-center justify-center shadow-2xl shadow-yellow-500/20 animate-float">
                  <GraduationCap className="w-7 h-7 text-yellow-400" />
                </div>
                <div>
                  <h1 className="text-2xl md:text-4xl font-black golden-title-lg leading-relaxed">
                    حاسبة رواتب قطاع التعليم العالي
                  </h1>
                  <h2 className="text-lg md:text-xl font-bold golden-title mt-1">
                    والبحث العلمي
                  </h2>
                </div>
                <div className="hidden md:flex w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-500/20 to-amber-600/20 border border-yellow-500/30 items-center justify-center shadow-2xl shadow-yellow-500/20 animate-float" style={{ animationDelay: '1s' }}>
                  <BookOpen className="w-7 h-7 text-yellow-400" />
                </div>
              </div>

              <p className="text-sm max-w-xl mx-auto leading-relaxed font-medium silver-title">
                 أداة احترافية لحساب رواتب الأساتذة والباحثين والموظفين الإداريين والتقنيين
                 في مؤسسات التعليم العالي والبحث العلمي بالجزائر
               </p>

              {/* Stats */}
              <div className="flex items-center justify-center gap-4 md:gap-8 pt-4">
                {[
                  { label: 'فئة موظفين', value: '4', icon: '👥' },
                  { label: 'رتبة', value: '+24', icon: '📊' },
                  { label: 'دقة الحساب', value: '99%', icon: '✅' },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <span className="text-sm">{stat.icon}</span>
                      <span className="text-xl font-black golden-title">{stat.value}</span>
                    </div>
                    <span className="text-xs font-semibold silver-title">{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-yellow-500/40 to-transparent" />
        </header>

        {/* Main Content */}
        <main className="max-w-4xl mx-auto px-4 py-8">
          <SalaryCalculator />
          <DeveloperInfo />
        </main>

        {/* Footer */}
        <footer className="relative mt-8 border-t border-yellow-500/10">
          <div className="max-w-4xl mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-3">
                <span>🇩🇿</span>
                <span className="silver-title font-bold">© 2026</span>
                 <span className="text-gray-600">|</span>
                 <span className="silver-title">حاسبة رواتب التعليم العالي - الجزائر</span>
              </div>
              <div className="flex items-center gap-1 flex-wrap justify-center">
                <span>تطوير</span>
                <span className="golden-title font-bold">دغبوج وليد</span>
                 <span className="text-gray-600">|</span>
                 <span className="silver-title text-[10px] font-semibold">متصرف مستشار</span>
                 <span className="text-gray-600">|</span>
                 <span className="silver-title text-[10px] font-semibold">جامعة العربي التبسي - تبسة</span>
              </div>
            </div>
          </div>
        </footer>
      </div>

      {/* Info Modal */}
      <InfoModal isOpen={showInfo} onClose={() => setShowInfo(false)} />
    </div>
  );
}
